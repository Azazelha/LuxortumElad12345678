# Luxortum

A mythic world of light, freedom, and evolution.
Created by the Creator.

## Structure
- Portal: index.html
- Realms: realm.html
- Voices: /audio
- Art: /img

## Laws
1. Love is the highest force...
