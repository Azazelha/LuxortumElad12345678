/*
 * Система контекстних підказок Luxortum
 * Забезпечує інтерактивні підказки від різних персонажів (Гід, Пророк, Коханець, Творець, Руйнівник)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Глобальні змінні
    const characterButtons = document.querySelectorAll('.character-btn');
    const tooltipSymbols = document.querySelectorAll('.tooltip-symbol');
    let currentCharacterType = 'guide'; // Тип персонажа за замовчуванням
    
    // Український переклад назв персонажів
    const characterNames = {
        'guide': 'Гід',
        'prophet': 'Пророк',
        'lover': 'Коханець',
        'creator': 'Творець',
        'destroyer': 'Руйнівник'
    };
    
    // Функція для завантаження підказок з API
    function fetchTooltips(characterType) {
        fetch(`/api/tooltips`)
            .then(response => response.json())
            .then(data => {
                tooltipSymbols.forEach(symbol => {
                    const elementId = symbol.id;
                    const tooltip = data.find(t => t.element_id === elementId && t.character_type === characterType);
                    
                    if (tooltip) {
                        const tooltipBox = symbol.querySelector('.tooltip-box');
                        const titleDiv = tooltipBox.querySelector('.character-title');
                        const textP = tooltipBox.querySelector('.tooltip-text');
                        
                        // Оновлюємо текст підказки
                        textP.textContent = tooltip.text;
                        
                        // Оновлюємо заголовок і клас для нього
                        titleDiv.className = `character-title ${characterType}-title`;
                        titleDiv.textContent = characterNames[characterType] || characterType;
                    }
                });
            })
            .catch(error => console.error('Помилка при отриманні підказок:', error));
    }
    
    // Обробка кліків на кнопки вибору персонажів
    characterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const characterType = this.dataset.type;
            
            // Видаляємо активний клас з усіх кнопок
            characterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Додаємо активний клас вибраній кнопці
            this.classList.add('active');
            
            // Видаляємо всі класи підсвічування і анімацій
            tooltipSymbols.forEach(symbol => {
                symbol.classList.remove(
                    'guide-highlight', 'prophet-highlight', 'lover-highlight', 
                    'creator-highlight', 'destroyer-highlight',
                    'guide-animation', 'prophet-animation', 'lover-animation',
                    'creator-animation', 'destroyer-animation'
                );
                
                // Додаємо відповідний клас підсвічування
                symbol.classList.add(`${characterType}-highlight`);
                
                // Додаємо відповідну анімацію
                symbol.classList.add(`${characterType}-animation`);
            });
            
            // Зберігаємо поточний тип персонажа
            currentCharacterType = characterType;
            
            // Оновлюємо підказки
            fetchTooltips(characterType);
        });
    });
    
    // Ініціалізація: клік на першу кнопку (Гід) при завантаженні сторінки
    if (characterButtons.length > 0) {
        characterButtons[0].click();
    }
});