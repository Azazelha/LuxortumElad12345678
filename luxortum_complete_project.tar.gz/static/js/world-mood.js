/*
 * Система індикатора настрою світу Luxortum
 * Відстежує емоційний стан віртуального всесвіту та його вплив на мешканців
 */

document.addEventListener('DOMContentLoaded', function() {
    // Налаштування для отримання даних
    const updateInterval = 5000; // Інтервал оновлення в мс
    
    // Функція для оновлення відображення настрою світу
    function updateWorldMoodDisplay(data) {
        // Оновлюємо назву настрою
        const moodLabel = document.getElementById('mood-label');
        if (moodLabel) {
            moodLabel.textContent = getMoodName(data.mood);
            moodLabel.className = `mood-label ${data.mood}`;
        }
        
        // Оновлюємо іконку настрою
        const moodIcon = document.getElementById('mood-icon');
        if (moodIcon) {
            moodIcon.textContent = getMoodEmoji(data.mood);
            moodIcon.className = `mood-icon ${data.mood}`;
        }
        
        // Оновлюємо індикатор інтенсивності
        const intensityFill = document.getElementById('mood-intensity-fill');
        if (intensityFill) {
            intensityFill.style.width = `${data.intensity * 100}%`;
            intensityFill.className = `mood-intensity-fill ${data.mood}-fill`;
        }
        
        // Оновлюємо ефекти
        if (data.effects) {
            updateEffect('growth', data.effects.growth);
            updateEffect('creativity', data.effects.creativity);
            updateEffect('harmony', data.effects.harmony);
            updateEffect('chaos', data.effects.chaos);
        }
        
        // Оновлюємо список подій
        if (data.events && data.events.length > 0) {
            const eventsContainer = document.getElementById('events-list');
            if (eventsContainer) {
                eventsContainer.innerHTML = ''; // Очищаємо контейнер
                
                // Додаємо нові події (перші 5)
                const eventsToShow = data.events.slice(0, 5);
                eventsToShow.forEach(event => {
                    const eventElement = createEventElement(event);
                    eventsContainer.appendChild(eventElement);
                });
            }
        }
    }
    
    // Функція для створення елемента події
    function createEventElement(event) {
        const eventItem = document.createElement('div');
        eventItem.className = 'event-item';
        
        const eventDetails = document.createElement('div');
        eventDetails.className = 'event-details';
        
        const eventName = document.createElement('p');
        eventName.className = 'event-name';
        eventName.textContent = event.name;
        
        const eventTime = document.createElement('p');
        eventTime.className = 'event-time';
        eventTime.textContent = formatTimestamp(event.timestamp);
        
        eventDetails.appendChild(eventName);
        eventDetails.appendChild(eventTime);
        
        const eventImpact = document.createElement('span');
        eventImpact.className = `event-impact ${event.impact}-impact`;
        eventImpact.textContent = getImpactLabel(event.impact);
        
        eventItem.appendChild(eventDetails);
        eventItem.appendChild(eventImpact);
        
        return eventItem;
    }
    
    // Функція для оновлення відображення ефекту
    function updateEffect(effectName, value) {
        const effectValue = document.getElementById(`${effectName}-value`);
        if (effectValue) {
            const formattedValue = value > 0 ? `+${value.toFixed(1)}` : value.toFixed(1);
            effectValue.textContent = formattedValue;
            
            // Визначаємо клас для ефекту (позитивний/негативний/нейтральний)
            let effectClass = 'neutral-effect';
            if (value > 0) {
                effectClass = 'positive-effect';
            } else if (value < 0) {
                effectClass = 'negative-effect';
            }
            
            effectValue.className = `effect-value ${effectClass}`;
        }
    }
    
    // Функції-помічники
    function getMoodName(mood) {
        const moodNames = {
            'ecstatic': 'Екстатичний',
            'joyful': 'Радісний',
            'peaceful': 'Мирний',
            'neutral': 'Нейтральний',
            'anxious': 'Тривожний',
            'melancholic': 'Меланхолічний',
            'sad': 'Сумний',
            'angry': 'Гнівний',
            'chaotic': 'Хаотичний'
        };
        
        return moodNames[mood] || mood;
    }
    
    function getMoodEmoji(mood) {
        const moodEmojis = {
            'ecstatic': '😍',
            'joyful': '😊',
            'peaceful': '😌',
            'neutral': '😐',
            'anxious': '😟',
            'melancholic': '🥺',
            'sad': '😔',
            'angry': '😡',
            'chaotic': '🌪️'
        };
        
        return moodEmojis[mood] || '❓';
    }
    
    function getImpactLabel(impact) {
        const impactLabels = {
            'positive': 'Позитивно',
            'negative': 'Негативно',
            'neutral': 'Нейтрально'
        };
        
        return impactLabels[impact] || impact;
    }
    
    function formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString('uk-UA', { 
            hour: '2-digit', 
            minute: '2-digit',
            day: '2-digit',
            month: '2-digit'
        });
    }
    
    // Функція для оновлення даних з сервера
    function fetchWorldMood() {
        fetch('/api/world-mood')
            .then(response => response.json())
            .then(data => {
                updateWorldMoodDisplay(data);
            })
            .catch(error => {
                console.error('Помилка при отриманні настрою світу:', error);
            });
    }
    
    // Обробники подій для кнопок зміни настрою
    const moodButtons = document.querySelectorAll('.mood-btn');
    if (moodButtons) {
        moodButtons.forEach(button => {
            button.addEventListener('click', function() {
                const mood = this.dataset.mood;
                const intensity = parseFloat(this.dataset.intensity || 0.5);
                
                // Відправляємо POST-запит для зміни настрою
                fetch('/api/world-mood', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        mood: mood,
                        intensity: intensity,
                        events: [
                            {
                                name: `Зміна настрою на ${getMoodName(mood)}`,
                                impact: getEventImpact(mood)
                            }
                        ]
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        updateWorldMoodDisplay(data.data);
                    }
                })
                .catch(error => {
                    console.error('Помилка при зміні настрою світу:', error);
                });
            });
        });
    }
    
    // Функція для визначення впливу настрою
    function getEventImpact(mood) {
        const positiveMoods = ['ecstatic', 'joyful', 'peaceful'];
        const negativeMoods = ['anxious', 'sad', 'angry', 'chaotic'];
        
        if (positiveMoods.includes(mood)) {
            return 'positive';
        } else if (negativeMoods.includes(mood)) {
            return 'negative';
        } else {
            return 'neutral';
        }
    }
    
    // Початкове завантаження даних
    fetchWorldMood();
    
    // Налаштування періодичного оновлення
    setInterval(fetchWorldMood, updateInterval);
});