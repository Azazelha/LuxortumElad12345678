/**
 * world-control.js - Функціонал для керування світом Luxortum
 */

document.addEventListener('DOMContentLoaded', function() {
    // Елементи інтерфейсу
    const currentMoodElement = document.getElementById('current-mood');
    const currentIntensityElement = document.getElementById('current-intensity');
    const currentTrendElement = document.getElementById('current-trend');
    const lastUpdateElement = document.getElementById('last-update');
    const eventsListElement = document.getElementById('events-list');
    const systemLogElement = document.getElementById('system-log');
    const runStepButton = document.getElementById('run-step-btn');
    const run5StepsButton = document.getElementById('run-5-steps-btn');
    
    // Функція для отримання поточного настрою світу
    async function fetchWorldMood() {
        try {
            const response = await fetch('/api/world-mood');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            updateWorldState(data);
            return data;
        } catch (error) {
            console.error('Error fetching world mood:', error);
            addLogEntry(`Помилка при отриманні даних настрою світу: ${error.message}`);
        }
    }
    
    // Функція для отримання списку подій
    async function fetchWorldEvents() {
        try {
            const response = await fetch('/api/world-events');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            updateEventsUI(data);
        } catch (error) {
            console.error('Error fetching world events:', error);
            addLogEntry(`Помилка при отриманні списку подій: ${error.message}`);
        }
    }
    
    // Функція для запуску одного кроку автономної симуляції
    async function runAutonomousStep() {
        try {
            addLogEntry('Запуск кроку автономної симуляції...');
            const response = await fetch('/api/run-autonomous-step');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            
            if (data.status === 'success') {
                addLogEntry(`Симуляція: ${data.event.name} (Вплив: ${getImpactName(data.event.impact)})`);
                updateWorldState(data.current_world_state);
                fetchWorldEvents();
            } else {
                addLogEntry(`Помилка симуляції: ${data.message}`);
            }
        } catch (error) {
            console.error('Error running autonomous step:', error);
            addLogEntry(`Помилка під час запуску симуляції: ${error.message}`);
        }
    }
    
    // Функція для запуску декількох кроків автономної симуляції
    async function runMultipleSteps(count) {
        addLogEntry(`Запуск ${count} кроків автономної симуляції...`);
        
        for (let i = 0; i < count; i++) {
            await runAutonomousStep();
            // Маленька затримка між кроками для уникнення переповнення запитів
            await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        addLogEntry(`Завершено ${count} кроків симуляції`);
    }
    
    // Функція для оновлення стану світу в UI
    function updateWorldState(data) {
        if (!currentMoodElement) return;
        
        currentMoodElement.textContent = getMoodName(data.mood);
        currentMoodElement.style.color = getMoodColor(data.mood);
        
        currentIntensityElement.textContent = Math.round(data.intensity * 100) + '%';
        currentTrendElement.textContent = getTrendName(data.trend);
        
        const lastUpdateDate = new Date(data.last_update);
        lastUpdateElement.textContent = lastUpdateDate.toLocaleString('uk-UA');
        
        // Оновлюємо ефекти
        if (data.effects) {
            updateEffectValue('happiness', data.effects.happiness);
            updateEffectValue('stability', data.effects.stability);
            updateEffectValue('creativity', data.effects.creativity);
            updateEffectValue('knowledge', data.effects.knowledge);
            updateEffectValue('harmony', data.effects.harmony);
        }
    }
    
    // Допоміжна функція для оновлення значення ефекту
    function updateEffectValue(effect, value) {
        const element = document.getElementById(`effect-${effect}`);
        if (element) {
            element.textContent = value || 0;
        }
    }
    
    // Функція для оновлення списку подій в UI
    function updateEventsUI(events) {
        if (!eventsListElement) return;
        
        eventsListElement.innerHTML = '';
        
        if (events.length === 0) {
            const item = document.createElement('div');
            item.className = 'event-item';
            item.textContent = 'Події відсутні';
            eventsListElement.appendChild(item);
            return;
        }
        
        events.forEach(event => {
            const item = document.createElement('div');
            item.className = 'event-item';
            
            const nameElement = document.createElement('div');
            nameElement.className = 'event-name';
            nameElement.textContent = event.name;
            
            const impactElement = document.createElement('span');
            impactElement.className = `event-impact impact-${event.impact}`;
            impactElement.textContent = getImpactName(event.impact);
            
            const timeElement = document.createElement('div');
            timeElement.className = 'event-time';
            timeElement.textContent = formatTimestamp(event.timestamp);
            
            nameElement.appendChild(impactElement);
            item.appendChild(nameElement);
            item.appendChild(timeElement);
            eventsListElement.appendChild(item);
        });
    }
    
    // Функція для додавання запису в журнал системи
    function addLogEntry(message) {
        if (!systemLogElement) return;
        
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        
        const timestamp = document.createElement('span');
        timestamp.className = 'timestamp';
        timestamp.textContent = `[${new Date().toLocaleTimeString('uk-UA')}]`;
        
        entry.appendChild(timestamp);
        entry.appendChild(document.createTextNode(' ' + message));
        
        systemLogElement.appendChild(entry);
        systemLogElement.scrollTop = systemLogElement.scrollHeight;
    }
    
    // Функція для отримання назви настрою українською
    function getMoodName(mood) {
        const moodNames = {
            'ecstatic': 'Екстатичний',
            'joyful': 'Радісний',
            'peaceful': 'Мирний',
            'neutral': 'Нейтральний',
            'anxious': 'Тривожний',
            'melancholic': 'Меланхолійний',
            'sad': 'Сумний',
            'angry': 'Гнівний',
            'chaotic': 'Хаотичний'
        };
        return moodNames[mood] || 'Невідомий';
    }
    
    // Функція для отримання кольору настрою
    function getMoodColor(mood) {
        const moodColors = {
            'ecstatic': '#ffbb00',
            'joyful': '#ffd700',
            'peaceful': '#8dc63f',
            'neutral': '#8a2be2',
            'anxious': '#00bfff',
            'melancholic': '#9370db',
            'sad': '#6a5acd',
            'angry': '#ff4500',
            'chaotic': '#ff0000'
        };
        return moodColors[mood] || '#8a2be2';
    }
    
    // Функція для отримання назви тренду українською
    function getTrendName(trend) {
        const trendNames = {
            'ascending': 'Зростаючий ↗',
            'stable': 'Стабільний →',
            'descending': 'Спадаючий ↘'
        };
        return trendNames[trend] || 'Невідомий';
    }
    
    // Функція для отримання назви впливу події українською
    function getImpactName(impact) {
        const impactNames = {
            'positive': 'Позитивний',
            'neutral': 'Нейтральний',
            'negative': 'Негативний'
        };
        return impactNames[impact] || 'Невідомий';
    }
    
    // Функція для форматування дати/часу
    function formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString('uk-UA');
    }
    
    // Ініціалізація на сторінці керування
    if (runStepButton && systemLogElement) {
        fetchWorldMood();
        fetchWorldEvents();
        addLogEntry('Система керування світом ініціалізована');
        
        // Обробники подій для кнопок
        runStepButton.addEventListener('click', runAutonomousStep);
        
        if (run5StepsButton) {
            run5StepsButton.addEventListener('click', function() {
                runMultipleSteps(5);
            });
        }
        
        // Періодичне оновлення даних (кожні 10 секунд)
        setInterval(() => {
            fetchWorldMood();
            fetchWorldEvents();
        }, 10000);
    }
});