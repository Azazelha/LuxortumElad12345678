/**
 * world-mood.js - Функціонал для роботи з настроєм світу Luxortum
 */

document.addEventListener('DOMContentLoaded', function() {
    // Функція для отримання поточного настрою світу
    async function fetchWorldMood() {
        try {
            const response = await fetch('/api/world-mood');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            updateUI(data);
        } catch (error) {
            console.error('Error fetching world mood:', error);
        }
    }
    
    // Функція для оновлення UI
    function updateUI(data) {
        // Оновлюємо назву настрою
        const moodNameElement = document.getElementById('mood-name');
        if (moodNameElement) {
            moodNameElement.textContent = getMoodName(data.mood);
            moodNameElement.style.color = getMoodColor(data.mood);
        }
        
        // Оновлюємо тренд
        const trendElement = document.getElementById('mood-trend');
        if (trendElement) {
            trendElement.textContent = getTrendName(data.trend);
        }
        
        // Оновлюємо інтенсивність
        const intensityPercent = Math.round(data.intensity * 100);
        const intensityValueElement = document.getElementById('intensity-value');
        if (intensityValueElement) {
            intensityValueElement.textContent = intensityPercent + '%';
        }
        
        const intensityFill = document.getElementById('intensity-fill');
        if (intensityFill) {
            intensityFill.style.width = intensityPercent + '%';
            intensityFill.style.backgroundColor = getMoodColor(data.mood);
        }
        
        // Оновлюємо ефекти
        if (data.effects) {
            updateEffectValue('happiness', data.effects.happiness);
            updateEffectValue('stability', data.effects.stability);
            updateEffectValue('creativity', data.effects.creativity);
            updateEffectValue('knowledge', data.effects.knowledge);
            updateEffectValue('harmony', data.effects.harmony);
        }
    }
    
    // Допоміжна функція для оновлення значення ефекту
    function updateEffectValue(effect, value) {
        const element = document.getElementById(`effect-${effect}`);
        if (element) {
            element.textContent = value || 0;
        }
    }
    
    // Функція для отримання назви настрою українською
    function getMoodName(mood) {
        const moodNames = {
            'ecstatic': 'Екстатичний',
            'joyful': 'Радісний',
            'peaceful': 'Мирний',
            'neutral': 'Нейтральний',
            'anxious': 'Тривожний',
            'melancholic': 'Меланхолійний',
            'sad': 'Сумний',
            'angry': 'Гнівний',
            'chaotic': 'Хаотичний'
        };
        return moodNames[mood] || 'Невідомий';
    }
    
    // Функція для отримання кольору настрою
    function getMoodColor(mood) {
        const moodColors = {
            'ecstatic': '#ffbb00',
            'joyful': '#ffd700',
            'peaceful': '#8dc63f',
            'neutral': '#8a2be2',
            'anxious': '#00bfff',
            'melancholic': '#9370db',
            'sad': '#6a5acd',
            'angry': '#ff4500',
            'chaotic': '#ff0000'
        };
        return moodColors[mood] || '#8a2be2';
    }
    
    // Функція для отримання назви тренду українською
    function getTrendName(trend) {
        const trendNames = {
            'ascending': 'Тренд: зростаючий ↗',
            'stable': 'Тренд: стабільний →',
            'descending': 'Тренд: спадаючий ↘'
        };
        return trendNames[trend] || '';
    }
    
    // Функція для форматування дати/часу
    function formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString('uk-UA');
    }
    
    // Функція для отримання історії змін настрою
    async function fetchMoodHistory() {
        try {
            const response = await fetch('/api/mood-history');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            updateHistoryUI(data);
        } catch (error) {
            console.error('Error fetching mood history:', error);
        }
    }
    
    // Функція для оновлення UI історії
    function updateHistoryUI(data) {
        const historyList = document.getElementById('mood-history');
        if (!historyList) return;
        
        historyList.innerHTML = '';
        
        if (data.length === 0) {
            const item = document.createElement('li');
            item.className = 'history-item';
            item.textContent = 'Історія поки що порожня';
            historyList.appendChild(item);
            return;
        }
        
        data.forEach(entry => {
            const item = document.createElement('li');
            item.className = 'history-item';
            
            const moodInfo = document.createElement('div');
            moodInfo.innerHTML = `<strong>${getMoodName(entry.mood)}</strong> (${Math.round(entry.intensity * 100)}%)`;
            moodInfo.style.color = getMoodColor(entry.mood);
            
            const timeInfo = document.createElement('div');
            timeInfo.className = 'timestamp';
            timeInfo.textContent = formatTimestamp(entry.timestamp);
            
            item.appendChild(moodInfo);
            item.appendChild(timeInfo);
            historyList.appendChild(item);
        });
    }
    
    // Ініціалізація - отримуємо настрій та історію на відповідних сторінках
    if (document.getElementById('mood-name') || document.getElementById('mood-history')) {
        fetchWorldMood();
        fetchMoodHistory();
        
        // Оновлюємо дані кожні 10 секунд
        setInterval(() => {
            fetchWorldMood();
            fetchMoodHistory();
        }, 10000);
    }
    
    // Додаємо обробники подій для кнопок настрою
    document.querySelectorAll('.mood-button').forEach(button => {
        button.addEventListener('click', async function() {
            const mood = this.getAttribute('data-mood');
            try {
                const response = await fetch('/api/world-mood', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ mood: mood })
                });
                
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                
                const data = await response.json();
                updateUI(data.data);
                setTimeout(fetchMoodHistory, 500); // Оновлюємо історію після зміни настрою
            } catch (error) {
                console.error('Error changing world mood:', error);
            }
        });
    });
});