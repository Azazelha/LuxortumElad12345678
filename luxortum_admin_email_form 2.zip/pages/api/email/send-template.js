import sgMail from '@sendgrid/mail';

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const templates = {
  investor: (name) => `Hi ${name},\n\nLuxortum is a creative-first SaaS for immersive art and sound...`,
  curator: (name) => `Dear ${name},\n\nWe invite you to explore Luxortum – a ritual-like gallery platform.`,
  artist: (name) => `Hey ${name},\n\nWe're inviting select creators to publish their work inside Luxortum...`,
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { name, email, template, message } = req.body;
  const text = templates[template](name) + "\n\n" + message;

  const msg = {
    to: email,
    from: process.env.SENDGRID_FROM_EMAIL,
    subject: 'Introducing Luxortum',
    text,
  };

  try {
    await sgMail.send(msg);
    res.status(200).json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}