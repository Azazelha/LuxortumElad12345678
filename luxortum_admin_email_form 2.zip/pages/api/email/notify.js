import { createClient } from '@sanity/client';
import sgMail from '@sendgrid/mail';

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const sanity = createClient({
  projectId: process.env.SANITY_PROJECT_ID,
  dataset: 'production',
  apiVersion: '2023-01-01',
  token: process.env.SANITY_API_TOKEN,
  useCdn: false,
});

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  try {
    const { imageId, subject, body } = req.body;

    const subscribers = await sanity.fetch(`*[_type == "subscriber" && active == true]{ email }`);
    const emails = subscribers.map((s) => s.email);

    const msg = {
      to: emails,
      from: process.env.SENDGRID_FROM_EMAIL,
      subject,
      text: body,
    };

    await sgMail.sendMultiple(msg);

    await sanity.create({
      _type: 'emailLog',
      subject,
      body,
      recipients: emails.length,
      image: { _type: 'reference', _ref: imageId },
      sentAt: new Date().toISOString(),
    });

    res.status(200).json({ success: true, sent: emails.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}